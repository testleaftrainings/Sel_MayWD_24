package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import utils.ReadExcel;

public class ProjectSpecificMethods {
	
	public ChromeDriver driver;
	public String fileName;
	public static Properties prop;
	
	@BeforeMethod
	public void preCondition() throws IOException {
        FileInputStream fis=new FileInputStream("src/test/resources/config.fr.properties");
		
		prop=new Properties();
		
		prop.load(fis);
		
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
}
	@DataProvider
	public String[][] sendData() throws IOException {
	return ReadExcel.readData(fileName);

	}
	
	
	
	@AfterMethod
	public void postCondition() {
		driver.close();

	}
	
}
