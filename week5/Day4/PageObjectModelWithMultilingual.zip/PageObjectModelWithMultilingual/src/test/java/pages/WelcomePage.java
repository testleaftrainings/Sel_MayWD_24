package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class WelcomePage extends ProjectSpecificMethods {
	
	public WelcomePage(ChromeDriver driver) {
		this.driver=driver;
	}
	
public WelcomePage verifyLogin() {
		String verifyLogin = driver.findElement(By.xpath("//h2[text()='Welcome ']")).getText();
		
if (verifyLogin.contains(prop.getProperty("verifyLogin"))) {
	System.out.println("Login succesful");
}

else {
	System.out.println("Not logged in");
}
return this;
	}
	
	public MyHomePage clickCRMSFA() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage(driver);

	}

}
