package constructors1;

public class LearnConstructor {
	
	
	int empId;
	String empName;
	boolean empStatus;
	
	
	public LearnConstructor() {
		
		//System.out.println("Default constructor");
	}
    public LearnConstructor(int empId,String empName,boolean empStatus) {
    	
    	this.empId=empId;
    	this.empName=empName;
    	this.empStatus=empStatus;
    	
		
		//System.out.println("Parameterized constructor");
	}
	
	
	
	public static void main(String[] args) {
		
		LearnConstructor obj=new LearnConstructor();
		System.out.println(obj.empId);
		System.out.println(obj.empName);
		System.out.println(obj.empStatus);
		
		LearnConstructor obj1=new LearnConstructor(7, "Vineeth", true);
		
		System.out.println("Empid: "+obj1.empId);
		System.out.println("Empid: "+obj1.empStatus);
		System.out.println("Empid: "+obj1.empName);
		
		
		
	}
	
	

}
