package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends ProjectSpecificMethods {
	

	@Then("It should navigate to the welcome page")
public WelcomePage verifyLogin() {
		String verifyLogin = driver.findElement(By.xpath("//h2[text()='Welcome ']")).getText();
if (verifyLogin.contains("Welcome")) {
	System.out.println("Login succesful");
}

else {
	System.out.println("Not logged in");
}
return this;
	}
	@When("Click the crmsfa link")
	public MyHomePage clickCRMSFA() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();

	}

}
