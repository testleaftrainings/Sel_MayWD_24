package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.And;

public class MyHomePage extends ProjectSpecificMethods {
	
	
	@And("Click the Leads button")
	public LeadsPage clickLead() {
		driver.findElement(By.linkText("Leads")).click();
return new LeadsPage();
	}
	
}
