package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CreateLeadPage extends ProjectSpecificMethods {

	
	
	@Given("Enter the Company name as (.*)$")
	public CreateLeadPage enterCompanyName(String cName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
        return this;
	}
	
	@And("Enter the FirstName as (.*)$")
	public CreateLeadPage enterFirstName(String fName) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
         return this;
	}
	@And("Enter the LastName as (.*)$")
	public CreateLeadPage enterLastName(String lName) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
      return this;
	}
	@When("Click the submit button")
	public ViewLeadPage clickSubmitButton() {
		driver.findElement(By.name("submitButton")).click();
        return new ViewLeadPage();
	}
	
}
