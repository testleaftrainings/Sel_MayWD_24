package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;
import pages.WelcomePage;

public class TC002_CreateLeadFunctionality extends ProjectSpecificMethods{
	
	

	@BeforeTest
	public void setvalues() {
		fileName="CreateLead";

	}
	
	
	@Test(dataProvider = "sendData")
	public void runCreateLead(String uName, String pWord, String cName, String fName, String lName) {
		LoginPage lp=new LoginPage(driver);
          lp.enterUsername(uName)
          .enterPassword(pWord)
          .clickLogin()
          .clickCRMSFA()
          .clickLead()
          .clickCreateLead()
          .enterCompanyName(cName)
          .enterFirstName(fName)
          .enterLastName(lName)
          .clickSubmitButton()
          .verifyLeads();
          
          }
	
}
