package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;
import pages.WelcomePage;

public class TC001_LoginFunctionality extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setvalues() {
		fileName="Login";
		testName="Login";
		testDescription="Login with valid credentials";
		testAuthor="Vineeth";
		testcategory="Sanity";

	}
	
	
	@Test(dataProvider = "sendData")
	public void runLogin(String uName, String pWord) throws IOException {
		LoginPage lp=new LoginPage();
          lp.enterUsername(uName)
          .enterPassword(pWord)
          .clickLogin()
          .verifyLogin();
          
          
          }
	
}
