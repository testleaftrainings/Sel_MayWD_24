package base;

public class LearnRandomNumber {
	
	
	public static void main(String[] args) {
		//System.out.println(Math.random());
		
		
		int randomNumber=(int) (Math.random()*99999999+9999999);
		
		System.out.println(randomNumber);
	}

}
