package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class ProjectSpecificMethods extends AbstractTestNGCucumberTests{
	
	//public static ChromeDriver driver;
	public String fileName, testName,testDescription,testAuthor,testcategory;
	public static ExtentReports extent;
	public static ExtentTest test;
	
	private static final ThreadLocal<ChromeDriver> cDriver=new ThreadLocal<ChromeDriver>();
	public void setDriver() {
		cDriver.set(new ChromeDriver());
		}
	public ChromeDriver getDriver() {
		return cDriver.get();
	}
	
	@BeforeMethod
	public void preCondition() {
	    setDriver();
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
}
	
	@BeforeSuite
	public void startReport() {
	    ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/result.html");
		extent=new ExtentReports();
		extent.attachReporter(reporter);

	}
	
	@BeforeClass
	public void testcaseDetails() {
		test = extent.createTest(testName, testDescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testcategory);

	}
	
	
	@AfterSuite
	public void stopReport() {
		extent.flush();

	}
	
	public void reportStep(String msg, String status) throws IOException {

	if (status.equalsIgnoreCase("Pass")) {
			test.pass(msg, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnapshot()+".png").build());
		}
	else if (status.equalsIgnoreCase("Fail")) {
		test.fail(msg);
		throw new RuntimeException();
	}

	}
	
	
	public int takeSnapshot() throws IOException {
		int randomNumber=(int) (Math.random()*99999999+9999999);
		File source = getDriver().getScreenshotAs(OutputType.FILE);
		 File dest=new File("./snaps/img"+randomNumber+".png");
		 FileUtils.copyFile(source, dest);
		 return randomNumber;

	}
	
	
	
	
	
	
	
	@DataProvider
	public String[][] sendData() throws IOException {
	return ReadExcel.readData(fileName);

	}
	
	@AfterMethod
	public void postCondition() {
		getDriver().close();

	}
	
}
