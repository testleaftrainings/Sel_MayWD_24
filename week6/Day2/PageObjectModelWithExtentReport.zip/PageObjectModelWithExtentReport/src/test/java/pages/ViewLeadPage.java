package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Then;

public class ViewLeadPage extends ProjectSpecificMethods{
	

	

	
	@Then("Lead should be created")
	public void verifyLeads() {
		String leadFirstName = getDriver().findElement(By.id("viewLead_firstName_sp")).getText();
		if (leadFirstName.equals("Vineeth")) {
			System.out.println("Lead is created");
		}
		
		else {
			System.out.println("Lead not created");
		}

	}
	
}
