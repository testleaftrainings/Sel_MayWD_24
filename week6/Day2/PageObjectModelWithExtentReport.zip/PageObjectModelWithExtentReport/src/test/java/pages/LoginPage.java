package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethods {
	
	
	
	@Given("Enter the username as {string}")
	public LoginPage enterUsername(String uName) throws IOException {
		try {
			getDriver().findElement(By.id("username1")).sendKeys(uName);
			reportStep("Username entered successfully", "Pass");
		} catch (Exception e) {
			reportStep("Username not entered successfully" +e, "Fail");
		}
         return this;
	}
	
	@And("Enter the password as {string}")
	public LoginPage enterPassword(String pWord) throws IOException {
		try {
			getDriver().findElement(By.id("password")).sendKeys(pWord);
			reportStep("Password Entered successfully", "Pass");
		} catch (Exception e) {
			reportStep("Password not entered successfully", "Fail");
		}
        return this;
	}
	@When("Click the login button")
	public WelcomePage clickLogin() throws IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("Login button clicked successfully", "Pass");
		} catch (Exception e) {
			reportStep("Login button not clicked successfully", "Fail");
		}
        return new WelcomePage();
	}

}
