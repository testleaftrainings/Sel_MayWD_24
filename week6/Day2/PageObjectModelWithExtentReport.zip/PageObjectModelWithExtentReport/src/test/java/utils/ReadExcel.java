package utils;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	public static String[][] readData(String fileName) throws IOException {
		
		//To open into the Workbook
		XSSFWorkbook wb=new XSSFWorkbook("./Data/"+fileName+".xlsx");
		
		//To enter into worksheet
		XSSFSheet sheet = wb.getSheetAt(0);
		
		
		//To get the row count
		
		int rowCount = sheet.getLastRowNum();
		
		//System.out.println("The row count is: "+rowCount);
		
		
		//int physicalNumberOfRows = sheet.getPhysicalNumberOfRows();
		
		//System.out.println("Original rowCount: "+physicalNumberOfRows);
		
		//To get the column count
		
	    int columnCount = sheet.getRow(0).getLastCellNum();
	    
	    
	   // short lastCellNum = sheet.getRow(0).getLastCellNum();
		
		//System.out.println("The column count: "+columnCount);
		
		
		//To get the particular value
		
		//String row1Column1Data = sheet.getRow(2).getCell(1).getStringCellValue();
		
		//System.out.println("Row1Column1Data: "+row1Column1Data);
		
	    
	    String[][] data=new String[rowCount][columnCount];
	    
	    
		    //Row
		for (int i = 1; i <= rowCount ; i++) {
			XSSFRow row = sheet.getRow(i);
			//Column
			for (int j = 0; j < columnCount; j++) {
				XSSFCell cell = row.getCell(j);
				String allDatas = cell.getStringCellValue();
				System.out.println("All datas are: "+allDatas);
				
				data[i-1][j]=allDatas;
				
				//data[0][0]
				//data[0][1]
				//data[0][2]
				//allDatas  [1][0]=TestLeaf    [1][1]=Vineeth   [1][2]=Rajendran
				
			}
			
	}
		wb.close();
		
		return data;
		
	}

}
